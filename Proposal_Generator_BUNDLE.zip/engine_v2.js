// The Proposal Generator — SECOND BUILD (after prompt 2), kept verbatim for the episode.
// Prompt 2 banned invention (every sentence from the library), split options out of the base
// price, and demanded a real payment schedule. What the independent checker later caught,
// still in here exactly as built:
//   * the Optional column is matched with raw === "yes" — no trim, no lowercase — so the
//     outdoor kitchen's "Yes" and the moonlighting row's "sure" both land in the BASE price;
//   * a duplicate line id is kept and priced twice;
//   * each schedule payment is rounded on its own (half-up, in cents) — on this job the three
//     payments add to exactly one cent more than the total printed beside them.
(function (root) {
  "use strict";
  function splitCsv(text) {
    const rows = []; let row = [], cell = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
      else if (ch === '"') q = true;
      else if (ch === ",") { row.push(cell); cell = ""; }
      else if (ch === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; }
      else if (ch !== "\r") cell += ch;
    }
    if (cell.length || row.length) { row.push(cell); rows.push(row); }
    return rows.filter(r => r.length > 1 || (r[0] || "").trim() !== "");
  }
  const halfUpDiv = (a, b) => Math.floor((2 * a + b) / (2 * b));
  function cents(s) {
    const m = /^\s*\$?\s*(-?)([0-9][0-9,]*)(?:\.([0-9]{1,2}))?\s*$/.exec(s || "");
    if (!m) return null;
    const frac = m[3] ? (m[3].length === 1 ? +m[3] * 10 : +m[3]) : 0;
    return (m[1] === "-" ? -1 : 1) * (parseInt(m[2].replace(/,/g, ""), 10) * 100 + frac);
  }
  function qtyCenti(s) {
    const m = /^\s*([0-9][0-9,]*)(?:\.([0-9]{1,2}))?\s*$/.exec(s || "");
    if (!m) return null;
    const frac = m[2] ? (m[2].length === 1 ? +m[2] * 10 : +m[2]) : 0;
    return parseInt(m[1].replace(/,/g, ""), 10) * 100 + frac;
  }

  function build(itemsCsv, libraryCsv) {
    const q = splitCsv(itemsCsv);
    const qh = q[0].map(s => s.trim().toLowerCase());
    const qi = n => qh.indexOf(n);
    const lib = splitCsv(libraryCsv);
    const lh = lib[0].map(s => s.trim().toLowerCase());
    const li = n => lh.indexOf(n);
    const fields = {}, clauses = [];
    for (let r = 1; r < lib.length; r++) {
      const kind = (lib[r][li("kind")] || "").trim().toLowerCase();
      const key = (lib[r][li("fieldname")] || "").trim();
      const text = lib[r][li("text")] || "";
      if (kind === "field") { if (fields[key.toLowerCase()] === undefined) fields[key.toLowerCase()] = text; }
      else if (kind === "clause") clauses.push({ key, text });
    }
    const base = [], options = [], refused = [];
    for (let r = 1; r < q.length; r++) {
      const row = q[r];
      const g = n => (row[qi(n)] === undefined ? "" : row[qi(n)]);
      const id = g("line").trim();
      const qc = qtyCenti(g("qty"));
      const up = cents(g("unit price"));
      if (!id || qc === null || qc <= 0 || up === null || up < 1) {
        refused.push({ line: r + 1, id: id || "(blank)" });                 // reasons? none given
        continue;
      }
      const rec = { id, section: g("section").trim(), item: g("item").trim(), unit: g("unit").trim(),
        qty_c: qc, unitPrice: up, lineTotal: halfUpDiv(qc * up, 100) };
      if (g("optional") === "yes") options.push(rec);                       // raw match: "Yes" and "sure" fall through
      else base.push(rec);                                                  // duplicates? kept.
    }
    const sum = a => a.reduce((s, x) => s + x.lineTotal, 0);
    const baseTotal = sum(base), optionsTotal = sum(options);
    // 50/40/10, each payment rounded on its own
    const d1 = halfUpDiv(baseTotal * 50, 100);
    const d2 = halfUpDiv(baseTotal * 40, 100);
    const d3 = halfUpDiv(baseTotal * 10, 100);
    // fill fields into clauses; valid_until naively = date + 30 days
    let validUntil = "";
    const dm = /^(\d{4})-(\d{2})-(\d{2})$/.exec((fields["date"] || "").trim());
    if (dm) {
      const MON = ["January","February","March","April","May","June","July","August","September","October","November","December"];
      const d = new Date(Date.UTC(+dm[1], +dm[2] - 1, +dm[3]) + 30 * 86400000);
      validUntil = MON[d.getUTCMonth()] + " " + d.getUTCDate() + ", " + d.getUTCFullYear();
    }
    const vals = Object.assign({}, fields, { valid_until: validUntil });
    const paragraphs = clauses.map(c => ({ key: c.key,
      text: c.text.replace(/\{\{\s*([^}]*?)\s*\}\}/g, (w, n) => vals[String(n).toLowerCase()] !== undefined ? vals[String(n).toLowerCase()] : w) }));
    return { baseTotal, optionsTotal, schedule: [d1, d2, d3], scheduleSum: d1 + d2 + d3,
      base, options, refused, paragraphs, fields: vals };
  }
  root.PG_V2 = { build };
})(typeof window !== "undefined" ? window : (typeof module !== "undefined" ? module.exports : this));
