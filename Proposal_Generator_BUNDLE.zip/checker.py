#!/usr/bin/env python3
"""Independent second implementation of the Proposal Generator's rules (shares no code with the
tool). Reads items.csv + library.csv (+ optional settings JSON), prints a JSON report in the same
shape as engine.js's build(). All money in integer cents; quantities in integer hundredths;
divisions via half-up integer arithmetic; dates via the standard library in UTC."""
import csv, datetime, io, json, re, sys

DEF = {"schedule": "50-40-10", "validityDays": 30, "detail": "itemized", "accepted": []}
PRESETS = {
    "50-40-10": [("Deposit to schedule the work", 50), ("Progress draw, mid-project", 40), ("Final payment at walkthrough", 10)],
    "40-40-20": [("Deposit to schedule the work", 40), ("Progress draw, mid-project", 40), ("Final payment at walkthrough", 20)],
    "thirds":   [("Deposit to schedule the work", 34), ("Progress draw, mid-project", 33), ("Final payment at walkthrough", 33)],
}
MONTHS = ["January", "February", "March", "April", "May", "June", "July",
          "August", "September", "October", "November", "December"]
MONEY = re.compile(r"^\s*\$?\s*(-?)([0-9][0-9,]*)(?:\.([0-9]{1,2}))?\s*$")
QTY = re.compile(r"^\s*([0-9][0-9,]*)(?:\.([0-9]{1,2}))?\s*$")
PLACEHOLDER = re.compile(r"\{\{\s*([^}]*?)\s*\}\}")


def half_up_div(a, b):
    return (2 * a + b) // (2 * b)


def pct_tenths(delta, base):
    s = -1 if delta < 0 else 1
    return s * half_up_div(abs(delta) * 1000, base)


def cents(s):
    m = MONEY.match(s or "")
    if not m:
        return None
    frac = m.group(3) or ""
    f = int(frac) * 10 if len(frac) == 1 else (int(frac) if frac else 0)
    v = int(m.group(2).replace(",", "")) * 100 + f
    return -v if m.group(1) == "-" else v


def qty_centi(s):
    m = QTY.match(s or "")
    if not m:
        return None
    frac = m.group(2) or ""
    f = int(frac) * 10 if len(frac) == 1 else (int(frac) if frac else 0)
    return int(m.group(1).replace(",", "")) * 100 + f


def line_money(qc, unit):
    return half_up_div(qc * unit, 100)


def rows_of(text):
    return [r for r in csv.reader(io.StringIO(text))
            if len(r) > 1 or (r and r[0].strip())]


def fmt_date(d):
    return f"{MONTHS[d.month - 1]} {d.day}, {d.year}"


def build(items_csv, library_csv, settings=None):
    S = dict(DEF)
    S.update(settings or {})
    if S["schedule"] not in PRESETS:
        S["schedule"] = DEF["schedule"]
    try:
        days = max(1, int(S.get("validityDays") or DEF["validityDays"]))
    except (TypeError, ValueError):
        days = DEF["validityDays"]
    detail = "summary" if S.get("detail") == "summary" else "itemized"

    ir = rows_of(items_csv)
    if not ir:
        raise ValueError("Paste the items file (or load the sample job).")
    ih = [c.strip().lower() for c in ir[0]]
    for n in ["line", "section", "item", "qty", "unit", "unit price", "optional"]:
        if n not in ih:
            raise ValueError("The items file is missing a “" + n + "” column.")
    ii = {n: ih.index(n) for n in ih}

    seen = set()
    lines = []
    refused_items = []
    item_rows = 0
    for ln, row in enumerate(ir[1:], start=2):
        item_rows += 1
        g = lambda n: (row[ii[n]] if ii[n] < len(row) else "")
        lid = g("line").strip()
        section = g("section").strip()
        qc = qty_centi(g("qty").strip())
        up = cents(g("unit price").strip())
        raw_flag = g("optional")
        flag = raw_flag.strip().lower()
        if not lid:
            refused_items.append({"line": ln, "id": "(blank)", "reason": "no line id"}); continue
        if lid in seen:
            refused_items.append({"line": ln, "id": lid, "reason": "duplicate line id — the first row was kept"}); continue
        if not section:
            refused_items.append({"line": ln, "id": lid, "reason": "no section"}); continue
        if qc is None or qc <= 0:
            refused_items.append({"line": ln, "id": lid, "reason": "quantity unreadable: “" + g("qty").strip() + "”"}); continue
        if up is None or up < 1:
            refused_items.append({"line": ln, "id": lid, "reason": "unit price unreadable: “" + g("unit price").strip() + "”"}); continue
        if flag in ("", "no"):
            optional = False
        elif flag == "yes":
            optional = True
        else:
            refused_items.append({"line": ln, "id": lid, "reason": "optional flag unreadable: “" + raw_flag.strip() + "” — use yes, no, or leave it blank"}); continue
        seen.add(lid)
        lines.append({"id": lid, "section": section, "item": g("item").strip(), "unit": g("unit").strip(),
                      "qty_c": qc, "unitPrice": up, "optional": optional, "lineTotal": line_money(qc, up)})

    lr = rows_of(library_csv)
    if not lr:
        raise ValueError("Paste the library file (or load the sample job).")
    lh = [c.strip().lower() for c in lr[0]]
    for n in ["kind", "fieldname", "text"]:
        if n not in lh:
            raise ValueError("The library file is missing a “" + n + "” column.")
    li = {n: lh.index(n) for n in lh}
    fields = {}
    clauses = []
    seen_clause = set()
    refused_library = []
    library_rows = 0
    for ln, row in enumerate(lr[1:], start=2):
        library_rows += 1
        g = lambda n: (row[li[n]] if li[n] < len(row) else "")
        kind = g("kind").strip().lower()
        key = g("fieldname").strip()
        text = g("text")
        if kind not in ("field", "clause"):
            refused_library.append({"line": ln, "key": key or "(blank)", "reason": "kind unreadable: “" + g("kind").strip() + "” — use field or clause"}); continue
        if not key:
            refused_library.append({"line": ln, "key": "(blank)", "reason": "no fieldname"}); continue
        if not str(text).strip():
            refused_library.append({"line": ln, "key": key, "reason": "empty text"}); continue
        if kind == "field":
            if key.lower() in fields:
                refused_library.append({"line": ln, "key": key, "reason": "duplicate field — the first row was kept"}); continue
            fields[key.lower()] = str(text)
        else:
            if key.lower() in seen_clause:
                refused_library.append({"line": ln, "key": key, "reason": "duplicate clause — the first row was kept"}); continue
            seen_clause.add(key.lower())
            clauses.append({"key": key, "text": str(text)})

    for req in ["business", "client", "project", "date"]:
        if req not in fields:
            raise ValueError("The library is missing the “" + req + "” field.")
    m = re.match(r"^\s*(\d{4})-(\d{2})-(\d{2})\s*$", fields["date"])
    try:
        date0 = datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None
    except ValueError:
        date0 = None
    if date0 is None:
        raise ValueError("The library “date” field must be a real date written YYYY-MM-DD.")
    valid_until = fmt_date(date0 + datetime.timedelta(days=days))

    base = [l for l in lines if not l["optional"]]
    options = [l for l in lines if l["optional"]]
    accepted_set = {str(x) for x in (S.get("accepted") or [])}
    accepted = [l for l in options if l["id"] in accepted_set]

    sec_order = []
    sec_map = {}
    for l in base:
        k = l["section"]
        if k not in sec_map:
            sec_map[k] = {"name": k, "subtotalC": 0, "lines": []}
            sec_order.append(k)
        sec_map[k]["subtotalC"] += l["lineTotal"]
        sec_map[k]["lines"].append({k2: l[k2] for k2 in ("id", "item", "unit", "qty_c", "unitPrice", "lineTotal")})
    sections = [sec_map[k] for k in sec_order]

    base_total = sum(l["lineTotal"] for l in base)
    options_total = sum(l["lineTotal"] for l in options)
    accepted_total = sum(l["lineTotal"] for l in accepted)
    contract_total = base_total + accepted_total

    preset = PRESETS[S["schedule"]]
    d1 = half_up_div(contract_total * preset[0][1], 100)
    d2 = half_up_div(contract_total * preset[1][1], 100)
    d3 = contract_total - d1 - d2
    schedule = [{"label": preset[0][0], "pct": preset[0][1], "amountC": d1},
                {"label": preset[1][0], "pct": preset[1][1], "amountC": d2},
                {"label": preset[2][0], "pct": preset[2][1], "amountC": d3}]

    values = dict(fields)
    values["valid_until"] = valid_until

    paragraphs = []
    missing_all = []

    def substitute(text):
        missing = []

        def repl(m2):
            name = m2.group(1)
            v = values.get(name.lower())
            if v is None:
                missing.append(name)
                return m2.group(0)
            return v
        return PLACEHOLDER.sub(repl, text), missing

    for c in clauses:
        out, missing = substitute(c["text"])
        paragraphs.append({"key": c["key"], "text": out})
        for mm in missing:
            missing_all.append({"clause": c["key"], "placeholder": mm})
    fields_filled = not missing_all and all("{{" not in p["text"] for p in paragraphs)

    provenance_ok = True
    for i, c in enumerate(clauses):
        again, _ = substitute(c["text"])
        if paragraphs[i]["key"] != c["key"] or paragraphs[i]["text"] != again:
            provenance_ok = False
            break

    counts = {"itemRows": item_rows, "libraryRows": library_rows, "base": len(base),
              "options": len(options), "accepted": len(accepted),
              "refusedItems": len(refused_items), "refusedLibrary": len(refused_library),
              "sections": len(sections)}
    rows_tie = counts["base"] + counts["options"] + counts["refusedItems"] == item_rows
    sections_tie = sum(s["subtotalC"] for s in sections) == base_total
    schedule_tie = d1 + d2 + d3 == contract_total
    share = pct_tenths(counts["refusedItems"], item_rows) if item_rows else 0
    trusted = rows_tie and sections_tie and schedule_tie and fields_filled and provenance_ok and share <= 200
    banner = ""
    if not trusted:
        if not rows_tie:
            banner = "DO NOT TRUST THIS PROPOSAL — the line buckets do not tie."
        elif not sections_tie:
            banner = "DO NOT TRUST THIS PROPOSAL — the section subtotals do not add to the base total."
        elif not schedule_tie:
            banner = "DO NOT TRUST THIS PROPOSAL — the payment schedule does not add to the contract total."
        elif not fields_filled:
            mm = missing_all[0]
            banner = ("DO NOT TRUST THIS PROPOSAL — a clause names a field the library does not fill: {{"
                      + mm["placeholder"] + "}} in the “" + mm["clause"] + "” clause.")
        elif not provenance_ok:
            banner = "DO NOT TRUST THIS PROPOSAL — a sentence in this document does not come from your library."
        else:
            banner = ("DO NOT TRUST THIS PROPOSAL — too many rows refused ("
                      + f"{share // 10}.{share % 10}" + "%). Fix the export and run it again.")

    return {
        "settings": {"schedule": S["schedule"], "validityDays": days, "detail": detail,
                     "accepted": [l["id"] for l in options if l["id"] in accepted_set]},
        "counts": counts,
        "money": {"baseTotal": base_total, "optionsTotal": options_total,
                  "acceptedTotal": accepted_total, "contractTotal": contract_total},
        "schedule": schedule,
        "sections": sections,
        "optionLines": [{**{k2: l[k2] for k2 in ("id", "item", "unit", "qty_c", "unitPrice", "lineTotal")},
                         "accepted": l["id"] in accepted_set} for l in options],
        "refusedItems": refused_items,
        "refusedLibrary": refused_library,
        "fields": {"business": fields["business"], "client": fields["client"], "project": fields["project"],
                   "contact": fields.get("contact", ""), "date": fields["date"].strip(), "valid_until": valid_until},
        "paragraphs": paragraphs,
        "recon": {"rowsTie": rows_tie, "sectionsTie": sections_tie, "scheduleTie": schedule_tie,
                  "fieldsFilled": fields_filled, "provenanceOk": provenance_ok,
                  "refusedShare_tenths": share, "trusted": trusted, "banner": banner},
    }


if __name__ == "__main__":
    items = open(sys.argv[1]).read()
    library = open(sys.argv[2]).read()
    st = json.loads(sys.argv[3]) if len(sys.argv) > 3 else None
    print(json.dumps(build(items, library, st), indent=1))
