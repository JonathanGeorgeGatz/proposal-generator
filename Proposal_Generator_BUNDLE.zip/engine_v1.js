// The Proposal Generator — FIRST BUILD (prompt 1), kept verbatim for the episode.
// Its sins, exactly as the naive build made them:
//   * it WRITES THE DOCUMENT ITSELF: a boilerplate intro, a "comprehensive five (5) year
//     workmanship warranty", "fully licensed, bonded and insured" — none of it from the
//     business's own library, all of it in a document a client signs;
//   * every line it can parse goes into ONE total — options, duplicates, everything;
//   * rows it cannot parse are silently skipped;
//   * floats and toFixed, and a hard-coded 50/30/20 schedule where each payment is rounded
//     on its own, so the three payments need not add to the total they sit under.
(function (root) {
  "use strict";
  function rows(text) {
    const out = []; let row = [], cell = "", q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
      else if (ch === '"') q = true;
      else if (ch === ",") { row.push(cell); cell = ""; }
      else if (ch === "\n") { row.push(cell); out.push(row); row = []; cell = ""; }
      else if (ch !== "\r") cell += ch;
    }
    if (cell.length || row.length) { row.push(cell); out.push(row); }
    return out.filter(r => r.length > 1 || (r[0] || "").trim() !== "");
  }
  function num(s) { const v = parseFloat(String(s || "").replace(/[$,]/g, "")); return isNaN(v) ? null : v; }

  function build(itemsCsv, libraryCsv) {
    const q = rows(itemsCsv);
    const qh = q[0].map(s => s.trim().toLowerCase());
    const qi = n => qh.indexOf(n);
    // pull a couple of names out of the library if they're there; invent the rest
    let client = "Valued Customer", business = "Your Company", project = "the project";
    for (const r of rows(libraryCsv).slice(1)) {
      const key = (r[1] || "").trim().toLowerCase();
      if (key === "client") client = r[2] || client;
      if (key === "business") business = r[2] || business;
      if (key === "project") project = r[2] || project;
    }
    const lines = [];
    let total = 0;
    for (let r = 1; r < q.length; r++) {
      const row = q[r];
      const qty = num(row[qi("qty")]), price = num(row[qi("unit price")]);
      if (qty === null || price === null) continue;              // silently skipped
      const lineTotal = +(qty * price).toFixed(2);
      total += lineTotal;
      lines.push({ id: (row[qi("line")] || "").trim(), section: (row[qi("section")] || "").trim(),
        item: (row[qi("item")] || "").trim(), qty, price, lineTotal });
    }
    total = +total.toFixed(2);
    const deposit = +(total * 0.5).toFixed(2);
    const progress = +(total * 0.3).toFixed(2);
    const finalPay = +(total * 0.2).toFixed(2);
    const document = [
      "Dear " + client + ",",
      "Thank you for the opportunity to earn your business! " + business + " is pleased to present this comprehensive proposal for " + project + ". Our team of seasoned professionals is committed to exceeding your expectations at every step of the journey.",
      "We are fully licensed, bonded and insured, and all work is backed by our comprehensive five (5) year workmanship warranty, because your peace of mind is our highest priority.",
      "The total investment for this project is $" + total.toFixed(2) + ", payable as follows: a deposit of $" + deposit.toFixed(2) + ", a progress payment of $" + progress.toFixed(2) + ", and a final payment of $" + finalPay.toFixed(2) + " upon completion.",
      "This proposal is valid for 30 days from today. We look forward to transforming your outdoor living space!",
      "Warm regards,", business,
    ];
    return { total, deposit, progress, finalPay, lines, document };
  }
  root.PG_V1 = { build };
})(typeof window !== "undefined" ? window : (typeof module !== "undefined" ? module.exports : this));
